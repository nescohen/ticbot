/* Nes Cohen 5/9/16
Ultimate Tic Tac Toe Bot v4, organized bitches
less EXTREMELY PRELIMINARY */

#include "definitions.h"
#include "globals.h"
#include "in_out.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <limits.h>
#include <time.h>

int main(int argc, char const *argv[])
{
	int error = 0;
	while(!error)
	{
		error = get_input();
	}
	return error;
}