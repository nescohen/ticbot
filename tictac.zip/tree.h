#ifndef TREE_H
#define TREE_H

Tree *construct_tree_ab(Board *current_state, char to_move, int ply, int millis);

#endif