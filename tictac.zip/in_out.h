#ifndef IN_OUT_H
#define IN_OUT_H

int get_input();

#endif